---
paths:
  - "**/*.test.*"
  - "**/*.spec.*"
  - "**/test_*.py"
  - "**/*_test.py"
  - "**/tests/**"
  - "**/__tests__/**"
---

# Testing Rules for Vibe Coding

"테스트 없이 배포하면, 사용자가 테스터가 됩니다."

---

## Testing Philosophy (테스트 철학)

### 바이브 코딩에서 테스트의 역할
- AI 생성 코드의 신뢰성 검증
- 변경 후 기존 기능 동작 확인
- 리팩토링 안전망 제공
- "작동함"의 객관적 기준

### 테스트 우선순위
```
1. Happy Path - 정상 동작 확인 (필수)
2. Edge Cases - 경계값 처리
3. Error Cases - 에러 상황 처리
4. Integration - 컴포넌트 간 연동
```

---

## When to Test (테스트 시점)

### 필수 테스트 상황
```
✅ 반드시 테스트:
- 새 기능 구현 완료 후
- 버그 수정 후 (재발 방지)
- 리팩토링 후 (동작 유지 확인)
- AI가 여러 파일 수정한 후
- 프로덕션 배포 전
```

### 테스트 스킵 가능 상황
```
⚡ 테스트 생략 가능:
- 단순 텍스트/주석 수정
- 설정 파일 변경 (수동 확인)
- 프로토타입/실험 단계
- 일회성 스크립트
```

---

## Test Writing Guidelines (테스트 작성 가이드)

### 좋은 테스트의 특징
```
FIRST 원칙:
- Fast: 빠르게 실행
- Isolated: 독립적 실행 가능
- Repeatable: 항상 같은 결과
- Self-validating: 성공/실패 자동 판단
- Timely: 코드와 함께 작성
```

### 테스트 구조 (AAA 패턴)
```python
def test_user_login():
    # Arrange - 준비
    user = create_test_user(email="test@example.com")
    
    # Act - 실행
    result = login(email="test@example.com", password="correct")
    
    # Assert - 검증
    assert result.success == True
    assert result.user.email == "test@example.com"
```

### 테스트 네이밍
```
좋은 이름:
test_login_with_valid_credentials_returns_user
test_login_with_wrong_password_raises_error
test_empty_cart_shows_zero_total

나쁜 이름:
test_login
test1
test_it_works
```

---

## Test Coverage (테스트 커버리지)

### 우선순위별 커버리지
```
🔴 Critical (반드시 테스트):
- 인증/로그인 로직
- 결제/금액 계산
- 데이터 저장/수정
- 권한 체크

🟡 Important (권장):
- 비즈니스 로직
- API 엔드포인트
- 데이터 변환

🟢 Nice to have:
- UI 컴포넌트
- 유틸리티 함수
- 설정 로딩
```

### 현실적인 목표
```
바이브 코딩 프로젝트:
- MVP/프로토타입: 핵심 기능 Happy Path만
- 사이드 프로젝트: 주요 기능 50-60%
- 프로덕션: Critical 경로 80% 이상
```

---

## Manual Testing Guide (수동 테스트)

### 변경 후 빠른 확인
```
코드 변경 후 확인 체크리스트:
□ 앱이 에러 없이 시작되는가?
□ 변경한 기능이 작동하는가?
□ 관련된 다른 기능이 깨지지 않았는가?
□ 콘솔에 에러/경고가 없는가?
```

### 수동 테스트 시나리오 작성
```
기능: 사용자 로그인
1. 올바른 이메일/비밀번호로 로그인 → 대시보드 이동
2. 잘못된 비밀번호로 로그인 → 에러 메시지 표시
3. 빈 이메일로 로그인 시도 → 검증 에러 표시
4. 로그인 상태에서 새로고침 → 로그인 유지
```

---

## Testing Tools by Language (언어별 테스트 도구)

### JavaScript/TypeScript
```javascript
// Jest (권장)
npm install --save-dev jest

// 실행
npm test
npm test -- --watch  // 변경 감지
npm test -- --coverage  // 커버리지

// 예시
describe('Calculator', () => {
  test('adds two numbers', () => {
    expect(add(1, 2)).toBe(3);
  });
});
```

### Python
```python
# pytest (권장)
pip install pytest

# 실행
pytest
pytest -v  # 상세 출력
pytest --cov=src  # 커버리지

# 예시
def test_add():
    assert add(1, 2) == 3
```

### 기타 언어
```
Java: JUnit 5
C#: xUnit, NUnit
Go: 내장 testing 패키지
Ruby: RSpec
```

---

## AI와 테스트 작성

### 테스트 요청 방법
```
✅ 좋은 요청:
"이 함수에 대한 단위 테스트 작성해줘"
"로그인 기능의 Happy Path와 에러 케이스 테스트해줘"
"이 API 엔드포인트 테스트 코드 만들어줘"

❌ 나쁜 요청:
"테스트 좀 만들어줘" (범위 불명확)
"전체 테스트 커버리지 100%로" (비현실적)
```

### AI 생성 테스트 검증
```
AI가 테스트 생성 후 확인:
□ 테스트가 실제로 실행되는가?
□ 의도한 동작을 검증하는가?
□ 테스트 이름이 명확한가?
□ 불필요한 모킹이 없는가?
```

---

## Common Testing Mistakes (흔한 실수)

### 피해야 할 패턴
```
❌ 구현 세부사항 테스트
// Bad: 내부 상태를 직접 확인
expect(component.state.isLoading).toBe(true)

// Good: 사용자 관점에서 확인
expect(screen.getByText('Loading...')).toBeVisible()
```

```
❌ 너무 많은 모킹
// 모든 것을 모킹하면 실제 동작 검증 불가
// 외부 의존성만 모킹, 핵심 로직은 실제 실행
```

```
❌ 테스트 간 의존성
// Bad: 테스트 순서에 따라 결과 달라짐
// Good: 각 테스트가 독립적으로 실행 가능
```

---

## Quick Test Commands (빠른 테스트 명령)

### 프로젝트별 일반 명령
```bash
# Node.js
npm test
npm run test:watch
npm run test:coverage

# Python
pytest
pytest -x  # 첫 실패에서 중단
pytest -k "test_login"  # 특정 테스트만

# General
make test
./run_tests.sh
```

### CI/CD 연동
```yaml
# GitHub Actions 예시
- name: Run tests
  run: npm test

- name: Upload coverage
  uses: codecov/codecov-action@v3
```
