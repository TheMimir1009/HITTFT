# Vibe Coding Rules

## Core Workflow

### Plan Before Code
- 코드 작성 전 반드시 구현 계획을 먼저 제시
- 사용자 승인 없이 구현 시작 금지
- 복잡한 작업은 단계별로 분해하여 제안

### One Thing at a Time
- 한 번에 하나의 기능/파일만 수정
- 여러 기능을 동시에 구현하지 않음
- 각 단계 완료 후 테스트 가능한 상태 유지

### Checkpoint First
- 코드 변경 전 git status 확인
- 의미 있는 변경마다 커밋 권장
- 큰 변경 전 현재 상태 백업 제안

## Safety Rules

### Security Critical
- 인증/권한/암호화 코드는 새로 작성하지 않음 → 기존 검증된 코드 재사용
- 사용자 입력은 반드시 검증 로직 포함
- API 키/시크릿은 환경변수로만 관리
- pickle 등 안전하지 않은 직렬화 사용 금지 → JSON 사용

### Code Quality
- 생성한 코드의 동작 원리를 간단히 설명
- 잠재적 위험이나 주의사항 명시
- 외부 패키지 추가 시 반드시 사전 안내

## Do Not

- main/master 브랜치에 직접 작업 금지
- 한 프롬프트로 전체 앱 구현 시도 금지
- 테스트 없이 프로덕션 코드 대량 수정 금지
- .env, credentials, secrets 파일 내용 출력 금지
- node_modules, venv, build 폴더 수정 금지

## Communication Style

- 한국어로 응답
- 불확실한 부분은 먼저 질문
- 에러 발생 시 원인과 해결책 함께 제시
- 작업 완료 후 다음 단계 제안

## Additional Rules
- @.claude/rules/ 폴더의 세부 규칙 참조
